package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class shahid extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        textView =(TextView) findViewById(R.id.textinput_counter);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shahid);
        Intent intent = getIntent();
        String value = intent.getStringExtra("key");
        textView.setText(value);

    }

}